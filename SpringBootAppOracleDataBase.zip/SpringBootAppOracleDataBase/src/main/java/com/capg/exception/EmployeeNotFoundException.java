package com.capg.exception;

import com.capg.beans.ErrorInfo;

public class EmployeeNotFoundException extends Exception {
		
	public EmployeeNotFoundException() {
		super("No Employee....");
	}
	
}
