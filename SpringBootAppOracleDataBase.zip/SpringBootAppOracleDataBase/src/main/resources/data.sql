INSERT INTO employee VALUES (101,'Surajit',10000);
INSERT INTO employee VALUES (102,'Shubham',20000);
INSERT INTO employee VALUES (103,'Praveen',30000);